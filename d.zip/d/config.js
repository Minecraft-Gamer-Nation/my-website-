module.exports = {
  bot: {
    prefix: "?", //Bot Prefix
    owners: ["759433582107426816"], //Bot Onwer ID
    maintenance: false,
    invite:
      "https://discord.com/api/oauth2/authorize?client_id=914298531651674123&permissions=8&redirect_uri=https%3A%2F%2Fyoutube.com%2Fminecraftgamernation0&response_type=code&scope=bot%20applications.commands", //Link Invite Bot
    bot_add_description:
      "You've just added me to **{guild}**.\nThank you for adding me to your server",
    bot_remove_description:
      "You got me out on the **{guild}** server, sorry if there's a mistake on me"
  },
  status: {
    stats: "online", //Status Bot <idle, online, dnd , invisible>
    type: "watching", //Playing Bot <PLAYING, WATCHING , and others>
    name: "testing" //Status Playing
  },//Unfinished Dashboard
  dash: {
    secret: "abNzNGLktUF0hSHPV6NasPwOctvbHsu1", //SECRET Bot
    id: "914298531651674123", //ID Bot
    url: "https://vibes.tk" //Ignore
  },
  server: {
    id: "914551022410686556", //Server ID
    invite: "https://discord.gg/3Wb64dZqzc" //Server Support
  },
  image: {
    welcome:
      "https://cdn.glitch.com/02e867ae-7c7c-4637-ace7-66ea251fe9d5%2Fwelcome.png?v=1613195262594", //Image WelcomeCard
    leave:
      "https://cdn.glitch.com/02e867ae-7c7c-4637-ace7-66ea251fe9d5%2Fwelcome.png?v=1613195262594", //Image LeaveCard
    level:
      "https://cdn.glitch.com/2337366e-e123-49db-827b-3e28e03e7910%2Fimages.jpeg?1623811398590", //Image LevelCard
    help:
      "https://cdn.discordapp.com/attachments/882863142286266420/931878147903852554/standard.gif", //Image Cmd Help.js
    guild_add:
      "https://cdn.discordapp.com/attachments/829696536396955649/856381256379400202/20210621_105311.jpg", //Image Guild Add
    leaderboard:
      "https://i.pinimg.com/736x/d1/00/7b/d1007b46e6175f49f53712f16e4f6a3c.jpg" //Image Leaderboard Card
  },
  mod: {
    muted_defauld: "Muted", // bot will make Roles muted for members who got muted

    //Coming soon auto mod!
    limit_warn: 0, //bot will kick member if it has 3 warns
    limit_muted: 0 //bot will kick member if it has 5 Muted
  },
  logs: {
    boton: "995413660887433288", //Channel ID Bot Online
    botadd: "992869777771081748", //Channel ID Bot Add In Guild
    botdel: "", //Channel ID Bot Remove in Guild
    botlogin: "there is not any yet", //Channel ID User Login
    botreport: "929800754590543932"
  },
  giveaway: {
    default: {
      storage: "./data/giveaways.json",
      default: {
        botsCanWin: false,
        embedColor: "#FF0000",
        embedColorEnd: "#FF0000",
        reaction: "882659092559196190"
      }
    }
  }
};