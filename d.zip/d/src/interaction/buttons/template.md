```js
module.exports = {
    name: "button_event_name",
    async execute(client, interaction) {
        //What to do.
    },
};
```